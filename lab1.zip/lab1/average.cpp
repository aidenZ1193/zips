#include <string.h>
#include <iostream>
#include <fstream>
#include <unistd.h>

FILE *file;

int read_file(FILE *file, double *sum){
	int i = 0;
	double s = 0;
	while(file != NULL && !feof(file)){
		fscanf(file, "%lf\n", &s);
		
		*sum += s;
		i++;
	}
	return i;
}

void open_file(char *filename){

	file = fopen(filename, "r");
	//if(file == NULL) printf("File %s opening failed\n", filename);		
}

int main(int argc, char *argv[]){

	if(argc != 2) return -1;

	open_file(argv[1]);
	double sum = 0;
	int n = 0;
	if (access(argv[1], R_OK) != 0)
                printf("File is not accessable.\n");
	else if((n = read_file(file, &sum)) == 0 || ftell(file) == 0)
		printf("File %s is empty.\n", argv[1]);
	else
		printf("File %s has an average = %f in %d numbers.\n", argv[1], sum/(double)n, n);
	return 0;
}
